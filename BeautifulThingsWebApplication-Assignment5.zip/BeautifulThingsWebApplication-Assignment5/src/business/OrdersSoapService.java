package business;

import java.util.List;

import javax.inject.Inject;
import javax.jws.WebMethod;
import javax.jws.WebService;

import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

@WebService()
public class OrdersSoapService {
		
	@WebMethod()
	public String sayHello(String name) {
	    System.out.println("Hello: " + name);
	    return "Hello " + name + "!";
	}
}
