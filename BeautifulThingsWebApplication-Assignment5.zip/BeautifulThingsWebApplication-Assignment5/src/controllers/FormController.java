package controllers;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.BeautifulThing;
import business.BusinessServiceInterface;

@ManagedBean
public class FormController {
	
	@Inject
	BusinessServiceInterface bs;
	
	public String onSubmitCreate() throws SQLException{
		FacesContext context = FacesContext.getCurrentInstance();
		BeautifulThing b = context.getApplication().evaluateExpressionGet(context,"#{beautifulThing}", BeautifulThing.class);
		
		bs.insertOne(b);
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("beautifulThing",b);
		
		return "ResponsePage.xhtml";
		
	}

	public FormController(){
		
	}
	
	public ArrayList<BeautifulThing> getAll() throws SQLException{	
		return bs.readAll();
	}
	
	public String onDelete(BeautifulThing b) throws SQLException{

		bs.deleteOne(b.getId());
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("beautifulThing",b);
		return "ResponsePage.xhtml";
	}
	
	public String onShowEdit(BeautifulThing b){
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("beautifulThing",b);
		return "EditForm.xhtml";
	}
	
	public String onSubmitEdit() throws SQLException{
		
		FacesContext context = FacesContext.getCurrentInstance();
		BeautifulThing b = context.getApplication().evaluateExpressionGet(context,"#{beautifulThing}", BeautifulThing.class);
		
		bs.updateOne(b.getId(), b);
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("beautifulThing",b);
		return "ResponsePage.xhtml";
	}
	
	public String showEntryForm(){
		return "EntryForm.xhtml";
	}
	
	public String showIndex(){
		return "Index.xhtml";
	}
}
