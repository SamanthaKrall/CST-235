package database;

import java.util.ArrayList;

import javax.ejb.Local;

import beans.BeautifulThing;

@Local
public interface DatabaseInterface {
	public int deleteOne(int id);
	public int insertOne(BeautifulThing b);
	public ArrayList<BeautifulThing> readAll();
	public int updateOne(int id, BeautifulThing b);
	public BeautifulThing readOne(int id);
	public ArrayList<BeautifulThing> searchFor(String name);
}
