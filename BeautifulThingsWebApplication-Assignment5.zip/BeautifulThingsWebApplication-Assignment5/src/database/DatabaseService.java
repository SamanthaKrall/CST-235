package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.BeautifulThing;

@Stateless
@Local
@Alternative
public class DatabaseService implements DatabaseInterface {
	int numberOfRowsAffected = 0;
	String dbURL = "jdbc:mysql://localhost:3307/beautifulThings";
	String user = "root";
	String password = "root";
	Connection c = null;
	int rowsAffected = 0;
	
	public int deleteOne(int id){
		PreparedStatement stmt = null;
		try {
			c= DriverManager.getConnection(dbURL, user, password);
			System.out.println("Connection is successful " + dbURL 
					+ " User: " +  user 
					+ " Password: " + password);
			stmt = c.prepareStatement("delete from beautifulThings.thingsTable where id = ?");
			stmt.setInt(1, id);
			rowsAffected = stmt.executeUpdate();
			System.out.println("Rows affected " + rowsAffected);
		} catch (SQLException e) {
			System.out.println("Error communicating with the database");
			e.printStackTrace();
		}finally{
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return numberOfRowsAffected;
	}
	
	public int insertOne(BeautifulThing b) {
		PreparedStatement stmt = null;
		try {
			c= DriverManager.getConnection(dbURL, user, password);
			System.out.println("Connection is successful " + dbURL 
					+ " User: " +  user 
					+ " Password: " + password);
			stmt = c.prepareStatement("insert into beautifulThings.thingsTable (id, thing_title, thing_description, thing_value) values (null, ?, ?, ?)");
			stmt.setString(1, b.getThingTitle());
			stmt.setString(2, b.getThingDescription());
			stmt.setInt(3, b.getRating());
			rowsAffected = stmt.executeUpdate();
			System.out.println("Rows inserted " + rowsAffected);
		} catch (SQLException e) {
			System.out.println("Error communicating with the database");
			e.printStackTrace();
		}finally{
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return numberOfRowsAffected;
	}
	
	public ArrayList<BeautifulThing> readAll() {
		
		ArrayList<BeautifulThing> everyone = new ArrayList<>();
		BeautifulThing b;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			c= DriverManager.getConnection(dbURL, user, password);
			System.out.println("Connection is successful " + dbURL 
					+ " User: " +  user 
					+ " Password: " + password);
			stmt = c.createStatement();
			rs = stmt.executeQuery("select * from beautifulThings.thingsTable");
			
			while(rs.next()){
				System.out.println("ID: " + rs.getInt("id")
				+" title = " + rs.getString("thing_title")
				+ " desc = " + rs.getString("thing_description")
				+ " rating = " + rs.getInt("thing_value"));
				b = new BeautifulThing(rs.getInt("id"),rs.getString("thing_title") , rs.getString("thing_description"), rs.getInt("thing_value"));
				everyone.add(b);
			}
		} catch (SQLException e) {
			System.out.println("Error communicating with the database");
			e.printStackTrace();
		}finally{
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return everyone;
	}
	
	public int updateOne(int id, BeautifulThing b) {
		PreparedStatement stmt = null;
		try {
			c= DriverManager.getConnection(dbURL, user, password);
			System.out.println("Connection is successful " + dbURL 
					+ " User: " +  user 
					+ " Password: " + password);
			stmt = c.prepareStatement("update beautifulThings.thingsTable set thing_title = ?, thing_description = ?, thing_value =? where id = ? ");
			stmt.setString(1, b.getThingTitle());
			stmt.setString(2, b.getThingDescription());
			stmt.setInt(3, b.getRating());
			stmt.setInt(4, id);
			rowsAffected = stmt.executeUpdate();
			System.out.println("Rows affected " + rowsAffected);
		} catch (SQLException e) {
			System.out.println("Error communicating with the database");
			e.printStackTrace();
		}finally{
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return numberOfRowsAffected;
	}

	@Override
	public BeautifulThing readOne(int id){
		BeautifulThing b = null;
		Connection c = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try{
			c = DriverManager.getConnection(dbURL, user, password);
			stmt = c.prepareStatement("select * from beautifulThings.thingsTable WHERE id=?");
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			while(rs.next()){
				b = new BeautifulThing(rs.getInt("id"), rs.getString("thing_title"), rs.getString("thing_description"), rs.getInt("rating"));

			}			
		} catch (SQLException e){
			System.out.println("Error communication with the database");
			e.printStackTrace();
		} finally {
			try{
				rs.close();
				stmt.close();
				c.close();
			} catch (SQLException e){
				e.printStackTrace();
			}
		}
		return b;
	}
	
	@Override
	public ArrayList<BeautifulThing> searchFor(String name){
		ArrayList<BeautifulThing> everyone = new ArrayList<>();
		BeautifulThing b = null;
		Connection c = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try{
			c = DriverManager.getConnection(dbURL, user, password);
			System.out.println("COnnection is succesful");
			stmt = c.prepareStatement("select * from beautifulThings.thingsTable WHERE thing_title LIKE ?");
			
			stmt.setString(1, "%"+name+"%");
			rs = stmt.executeQuery();
			while(rs.next()){
				System.out.println("id = " + rs.getInt("id") + " title " + rs.getString("thing_title"));
				b= new BeautifulThing(rs.getInt("id"), rs.getString("thing_title"), rs.getString("thing_description"), rs.getInt("rating"));
				everyone.add(b);
			}	
		} catch (SQLException e){
			System.out.println("Error communcation with the database");
			e.printStackTrace();
		} finally {
			try{
				rs.close();
				stmt.close();
				c.close();
			} catch (SQLException e){
				e.printStackTrace();
			}
		}
		return everyone;
	}
}
