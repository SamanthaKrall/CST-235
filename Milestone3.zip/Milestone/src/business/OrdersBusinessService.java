package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import Milestone.Animals;

@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {

	List<Animals> animal = new ArrayList<Animals>();
	
	@Override
	public void test() {
		System.out.println("Printing from @OrdersBusinessService test method");
	}

	public OrdersBusinessService(){
		animal.add(new Animals((int)1,"Wubs", "Orange", (int)6, "Domestic Longhair", "Stomach", "None", "Anti Inflammatory", "05/13/12", "05/14/12", "05/17/12"));
		animal.add(new Animals((int)2,"Shadow", "Black", (int)6, "Domestic", "None", "None", "None", "05/13/12", "05/14/12","05/17/12"));
		animal.add(new Animals((int)3,"Zorc", "Black", (int)6, "Domestic", "Overweight", "Non Social", "Diet", "05/13/12", "05/14/12","05/17/12"));
		animal.add(new Animals((int)4,"Bob", "White with Black Spots", (int)6, "Domestic", "None", "None", "None", "05/13/12", "05/14/12","05/17/12"));
		animal.add(new Animals((int)5,"Zetsu", "Black", (int)8, "Domestic", "None", "None", "None", "05/13/12", "05/14/12","05/17/12"));
		animal.add(new Animals((int)6,"Amelia", "Black", (int)4, "Norwegian Elkhound", "Underbite", "None", "None", "05/13/16", "05/14/16","05/17/16"));
		
	}
	
	@Override
	public List<Animals> getOrders() {
		// TODO Auto-generated method stub
		return animal;
	}

	@Override
	public void setOrders(List<Animals> animal) {
		// TODO Auto-generated method stub
		this.animal = animal;
	}

}
