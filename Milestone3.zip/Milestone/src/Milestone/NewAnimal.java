package Milestone;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@SessionScoped
public class NewAnimal {
	
	@NotNull(message="Please enter an Animal ID. This is a required field.")
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public String getHealthIssues() {
		return healthIssues;
	}

	public void setHealthIssues(String healthIssues) {
		this.healthIssues = healthIssues;
	}

	public String getBehavioralIssues() {
		return behavioralIssues;
	}

	public void setBehavioralIssues(String behavioralIssues) {
		this.behavioralIssues = behavioralIssues;
	}

	public String getVetTreatment() {
		return vetTreatment;
	}

	public void setVetTreatment(String vetTreatment) {
		this.vetTreatment = vetTreatment;
	}

	public String getIntakeDate() {
		return intakeDate;
	}

	public void setIntakeDate(String intakeDate) {
		this.intakeDate = intakeDate;
	}

	public String getAvailAdoptDate() {
		return availAdoptDate;
	}

	public void setAvailAdoptDate(String availAdoptDate) {
		this.availAdoptDate = availAdoptDate;
	}

	public String getAdoptedDate() {
		return adoptedDate;
	}

	public void setAdoptedDate(String adoptedDate) {
		this.adoptedDate = adoptedDate;
	}

	@NotNull(message="Please enter a Name. This is a required field.")
	@Size(min=4, max=15)
	private String name;
	
	@NotNull(message="Please enter a Color. This is a required field.")
	@Size(min=4, max=15)
	private String color;
	
	@NotNull(message="Please enter an Age. This is a required field.")
	private int age;
	
	@NotNull(message="Please enter a Breed. This is a required field.")
	@Size(min=4, max=15)
	private String breed;
	
	@NotNull(message="Please enter any Health Issues. This is a required field.")
	@Size(min=4, max=15)
	private String healthIssues;
	
	@NotNull(message="Please enter any Bahavioral Issues. This is a required field.")
	@Size(min=4, max=15)
	private String behavioralIssues;
	
	@NotNull(message="Please enter any Vet Treatment. This is a required field.")
	@Size(min=4, max=15)
	private String vetTreatment;
	
	@NotNull(message="Please enter an Intake Date. This is a required field.")
	@Size(min=4, max=15)
	private String intakeDate;
	
	@NotNull(message="Please enter a Date Available for Adoption. This is a required field.")
	@Size(min=4, max=15)
	private String availAdoptDate;
	
	@NotNull(message="Please enter a Date Adopted. This is a required field.")
	@Size(min=4, max=15)
	private String adoptedDate;

	public NewAnimal(){
		id = 0;
		name = "";
		color = "";
		age = 0;
		breed = "";
		healthIssues = "";
		behavioralIssues = "";
		vetTreatment = "";
		intakeDate = "";
		availAdoptDate = "";
		adoptedDate = "";
	}
}
