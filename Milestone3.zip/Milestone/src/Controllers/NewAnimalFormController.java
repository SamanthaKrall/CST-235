package Controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import Milestone.NewAnimal;;

@ManagedBean
public class NewAnimalFormController {

	public String newAnimal(){
		FacesContext context = FacesContext.getCurrentInstance();
		NewAnimal newAnimal = context.getApplication().evaluateExpressionGet(context, "#{NewAnimal}", NewAnimal.class);
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("NewAnimal", newAnimal);
		return "NewAnimalRegister.xhtml";
	}
}
