package Controllers;

import javax.faces.bean.ManagedBean;
import javax.inject.Inject;

import business.OrdersBusinessInterface;

@ManagedBean
public class LoginResponseController {
	
	@Inject
	OrdersBusinessInterface products;
	
	public String newAnimal(){
		System.out.println("Right here");
		return "NewAnimalResponse.xhtml";
		
	}
}
