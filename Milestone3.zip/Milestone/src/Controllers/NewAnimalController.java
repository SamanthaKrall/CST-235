package Controllers;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class NewAnimalController {

	public String newAnimal(){	
		System.out.println("You hit the new animal button #1");
		return "NewAnimalResponse.xhtml";
	}
}
