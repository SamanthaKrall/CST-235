package Controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import Milestone.User;
import business.OrdersBusinessInterface;

@ManagedBean
public class LoginFormController {
	
	@Inject
	OrdersBusinessInterface products;
	
	public String onLogin(){
		//get the user values from the loginForm
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		//print a message to the console to let us know which business services is selected.
		products.test();
		
		//put the user object into the POST request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		//show the next page
		return "loginResponse.xhtml";
	}
	public String register(){
		return "RegisterResponse.xhtml";
	}
	
	public OrdersBusinessInterface getService() {
		return products;
		
	}
}

